# landscape.vim
## editor be colorful, life be joyful

![shell script](https://raw.githubusercontent.com/wiki/itchyny/landscape.vim/image/1.png)

![vimfiler](https://raw.githubusercontent.com/wiki/itchyny/landscape.vim/image/2.png)

![C source](https://raw.githubusercontent.com/wiki/itchyny/landscape.vim/image/3.png)

![GHCi in vimshell](https://raw.githubusercontent.com/wiki/itchyny/landscape.vim/image/4.png)

![vimfiler and vimshell](https://raw.githubusercontent.com/wiki/itchyny/landscape.vim/image/5.png)

## Installation
Install with your favorite plugin manager.

## Author
itchyny (https://github.com/itchyny)

## License
This software is released under the MIT License, see LICENSE.
