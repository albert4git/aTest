#!/usr/bin/env python
# encoding: utf-8

"""Entry point for all thinks UltiSnips."""

from UltiSnips.snippet_manager import UltiSnips_Manager
