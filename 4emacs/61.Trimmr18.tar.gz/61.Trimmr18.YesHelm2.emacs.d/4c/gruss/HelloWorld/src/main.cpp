#include "hello.h"

int main(int argc, const char* argv[])
{
        Hello();
        return 0;
}
