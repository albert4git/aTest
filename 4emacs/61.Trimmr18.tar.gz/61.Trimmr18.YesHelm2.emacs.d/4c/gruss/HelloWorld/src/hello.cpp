#include <stdio.h>
#include "hello.h"

void Hello()
{
        printf("Hello World !\n");
        printf("123 World !\n");
}
