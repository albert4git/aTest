// 'Hello World!' program 
 
#include <iostream>
 
int main()
{
    int i; 
  std::cout << "Hello World!" << std::endl;
  return 0;
}
